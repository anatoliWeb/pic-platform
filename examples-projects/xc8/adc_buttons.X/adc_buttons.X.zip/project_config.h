#ifndef EXAMPLES_PROJECTS_PROJECT_CONFIG_H
#define EXAMPLES_PROJECTS_PROJECT_CONFIG_H

#include "../../../core/config/project_config_template.h"

#endif /* EXAMPLES_PROJECTS_PROJECT_CONFIG_H */